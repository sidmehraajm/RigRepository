PyFlow - visual scripting framework for python!
===============================================


.. toctree::
   :maxdepth: 1

   intro
   changelog

.. toctree::
   :caption: The Basics
   :maxdepth: 2

   appanatomy
   basics

.. toctree::
   :caption: Advanced
   :maxdepth: 2

   datalayout
   nodeanatomy
   extending


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`

.. toctree::
   :caption: Extra Information
   :maxdepth: 1

   extra
