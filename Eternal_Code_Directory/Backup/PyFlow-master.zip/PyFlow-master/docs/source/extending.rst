Extending
=========

Simplest way to extend the editor is to use plugin wizard.
Invoke menu ``Plugins -> Create package...`` and follow this guy instructions

.. image:: resources/wizard.png
