PyFlow.Packages.PyFlowBase.PrefsWidgets package
===============================================

Submodules
----------

PyFlow.Packages.PyFlowBase.PrefsWidgets.General module
------------------------------------------------------

.. automodule:: PyFlow.Packages.PyFlowBase.PrefsWidgets.General
   :members:
   :show-inheritance:

PyFlow.Packages.PyFlowBase.PrefsWidgets.InputPrefs module
---------------------------------------------------------

.. automodule:: PyFlow.Packages.PyFlowBase.PrefsWidgets.InputPrefs
   :members:
   :show-inheritance:

PyFlow.Packages.PyFlowBase.PrefsWidgets.ThemePrefs module
---------------------------------------------------------

.. automodule:: PyFlow.Packages.PyFlowBase.PrefsWidgets.ThemePrefs
   :members:
   :show-inheritance:


Module contents
---------------

.. automodule:: PyFlow.Packages.PyFlowBase.PrefsWidgets
   :members:
   :show-inheritance:
