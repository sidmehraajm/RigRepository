.. _changelog:

Changelog
#########

PyFlow releases use a `semantic versioning <http://semver.org>`_ policy.


.. literalinclude:: ../../CHANGELOG.rst
    :language: rst
