Node anatomy
============

Generic node anatomy.

.. image:: resources/nodeAnatomy.png
