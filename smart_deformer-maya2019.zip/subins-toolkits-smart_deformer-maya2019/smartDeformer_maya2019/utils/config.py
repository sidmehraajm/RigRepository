'''
config.py 0.0.1 
Date: January 15, 2019
Last modified: April 23, 2019
Author: Subin. Gopi(subing85@gmail.com)

# Copyright(c) 2019, Subin Gopi
# All rights reserved.

# WARNING! All changes made in this file will be lost!

Description
    None.
'''


def get_conig():
    return 'Linux', 'maya', '2019', '2.7.11'


def get_tool_kit():
    return 'smart_deformer_maya2019', 'Smart Deformer Maya-2019', '0.0.2'
